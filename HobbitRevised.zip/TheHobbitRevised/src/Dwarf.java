public class Dwarf extends Traveler
{
	private String name;
	//Dwarves will need a constructor, but there's nothing new for them beyond
	//  what Traveler offers.  
	//Dwarves travel just like any other Traveler. Do they need a travel method?  
	//  Try it without and find out.  =]  
	
	//Complete the constructor
	public Dwarf(String name)
	{
		super(name);
		this.name = name;
	}
	
}
