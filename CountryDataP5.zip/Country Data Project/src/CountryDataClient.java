/*
 * Description: This is the client that will process the file and print results  
 * @author: natalieluong
 * @version: 10.07.22
 */
import java.io.File;   
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class CountryDataClient {

	public static void main(String[] args) throws FileNotFoundException {
		
		//*/
		
		//Part 5
		
		File inputFile = new File("_NL -Country Data Set - Sheet1.csv");
		Scanner input = new Scanner(inputFile);
		
		//Scans first line:
		String series = input.nextLine();
		int whereComma = series.indexOf(","); //Finds where the commas start and cuts them off.
		String seriesName = series.substring(0,whereComma); //Only stores the series name without the commas.
		
		//Scans second line:
		String countryLine = input.nextLine();
		String[] splitSecondLn = countryLine.split(",");
		ArrayList<Integer> onlyYears = new ArrayList<Integer>();
				//Only makes a copy of the years.
		for(int i = 1; i < splitSecondLn.length; i++) {
			onlyYears.add(Integer.parseInt(splitSecondLn[i]));
		}
		
		
		
		ArrayList<Country> storeObjs = new ArrayList<Country>(); 
		
		while(input.hasNextLine() == true) { //While there is something in the next line.
			String oneCountryData = input.nextLine(); //Scans third line.
			String[] splitData = oneCountryData.split(","); //Only get country and values
			String country = splitData[0]; //Country is the first in the line
			ArrayList<Double> data = new ArrayList<Double>(); 
				  //DO NOT REMOVE THIS FROM THE LOOP!!!
			     //ENSURES THAT THE LIST OF DATA WILL RESET FOR EVERY COUNTRY!!!!
			for(int i = 1; i < splitData.length; i++) { //Everything after index 0 are the values
				data.add(Math.round(Double.parseDouble(splitData[i]) * 100.0)/100.0);
			}
			Country myCountry = new Country(country, seriesName, onlyYears, data);
			storeObjs.add(myCountry); //Adding to the new CountryObject storage
			
			//System.out.println(summarizeCountry(country, seriesName, onlyYears, data));
		}
		for(int i = 0; i < storeObjs.size(); i++) {
			System.out.println(storeObjs.get(i));
		}
		input.close();
		
	}
	//Methods for Part 5
	public static void removeByName(ArrayList<Country> countries, String name) {
		for(int i = 0; i < countries.size(); i++) {
			if(countries.get(i).getCountry().equals(name)) {
				countries.remove(countries.indexOf(countries.get(i)));
			}
		}
	}
	//This method removes the country and all its data from the list of countries.
	
	public static void removeNoTrend(ArrayList<Country> countries) {
		for(int i = 0; i < countries.size(); i++) {
			if(countries.get(i).getTrend().equals("no trend")) {
				countries.remove(i);
				i--;
			}
		}
	}
	//This method removes the countries that have no trend.
	
	
	public static ArrayList<String> getListBasedOnTrend(ArrayList<Country> countries, 
		    String trendType){
		ArrayList<String> listOfATrend = new ArrayList<>();
		for(int i = 0; i < countries.size(); i++) {
			if(trendType.equals("up")) {
				if(countries.get(i).getTrend().equals("up")) {
					listOfATrend.add(countries.get(i).getCountry());
				}
			}else {
				if(trendType.equals("down")) {
					if(countries.get(i).getTrend().equals("down")) {
						listOfATrend.add(countries.get(i).getCountry());
					}
				}else {
					if(trendType.equals("no trend")) {
						if(countries.get(i).getTrend().equals("no trend")) {
							listOfATrend.add(countries.get(i).getCountry());
						}
					}else {
						throw new IllegalArgumentException("Enter something besides 'up', 'down', or 'no trend'");
					}
				}
			}
		}
		return listOfATrend;
	}
	//This method returns a list of countries with the trend inputed in the parameter. 
	}
	
