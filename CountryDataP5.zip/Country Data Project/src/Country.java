/*
 * Description: This country class makes new instances of countries and will process its data.  
 * @author: natalieluong
 * @version: 02.09.23
 */
import java.util.ArrayList;

public class Country {
	private String name;
	private String series;
	private ArrayList<Integer> years;
	private ArrayList<Double> values;
	//Initializes all private fields that store a country's data
	
	public Country(String countryName, String series, ArrayList<Integer> years, ArrayList<Double> data) {
		this.name = countryName;
		this.series = series;
		this.years = years;
		this.values = data;
		
	}
	//Constructor for Country class
	//Sets all the parameters to the respective fields
	
	public String getSeries() {
		String noUnits = "";
		if((series.contains("("))) {
			int firstPar = series.indexOf("("); 
			noUnits = series.substring(0,firstPar);
			return noUnits;
		}else {
			return series;
		}
	}
	//Returns the name of the series without the units at the end
	//This will make it easier to make an acronym for the country names
	//and is printed in the title of each country.
	
	public ArrayList<Integer> getYears() {
		return this.years;
	}
	//This getter returns the set of years.
	
	public String getCountry() {
		return this.name;
	}
	//This getter returns the country name.
	
	public ArrayList<Double> getData() {
		return this.values;
	}
	//This getter returns the set of data.
	
	public void setSeries(String str) {
		series = str;
	}
	//This setter sets the private field of 
	//the series name with the input.
	
	public void setData(ArrayList<Double> values) {
		this.values = values;
	}
	//This setter sets the private field of values with the input.
	
	public String getUnits() {
		int parOne = series.indexOf("(");
		int parTwo = series.indexOf(")");
		String units = "";
		for(int i = parOne + 1; i < parTwo; i++) {
			units += series.charAt(i);
		}
		return units;
	}
	//This method returns the units for the stored data.  
	//The string that is returned should not include parentheses.  
	//In the example above, a call to getUnits would return:  % of population.
	

	public String getAcronym() {
		String acr = "";
		String[] exclude = {"of", "in", "the", "at", "to", "by", "per", "on", "a", "an"};
		String[] newSeries = getSeries().split(" ");

		for(String n : newSeries) {
			boolean skip = false; 
			for(String m : exclude) {
				
				if(n.equals(m)) {
					skip = true;
				}
			}
			if(skip == false) {
				acr += n.charAt(0);
			}
		}
		return acr.toUpperCase();
	}


	//This method returns an acronym made of the first letter in each of the words in the series name, 
	//but excludes: of, in, the, at, to, by, per, on, a, an.  


	public double min() {
		double min = values.get(0);
		for(int j = 0; j < (this.values).size(); j++) {
			if(values.get(j) < min) {
				min = values.get(j);
			}
		}
		return min;
	}
	
	//This method returns the lowest value in the data stored for the country.


	public double max() {
		double max = values.get(0);
		for(int j = 0; j < (this.values).size(); j++) {
			if(values.get(j) > max) {
				max = values.get(j);
			}
		}
		return max;
	}

	//This method returns the highest value in the data stored for the country.


	public void addDataPoint(int year, double newDatum) {
		years.add(year);
		values.add(newDatum);
	}
	
	//This method adds a new data point for a country object. 
	public void editDataPoint(int year, double newDatum) {
		Integer whereData = years.indexOf(year);
		values.set(whereData, newDatum);
	}
	
	//This method changes the data of the year in a country object.
	private boolean trendsUp() {
		boolean torf = true;
		for(int i = 0; i < values.size() - 1; i++) {
			if(values.get(i) > values.get(i+1)) {
				torf = false;
			}
		}
		return torf;
	}
	

	//This method returns a boolean representing 
	//whether each successive data point is higher than the previous one. 

	private boolean trendsDown() {
		boolean torf = true;
		for(int i = 0; i < values.size() - 1; i++) {
			if(values.get(i) < values.get(i+1)) {
				torf = false;
			}
		}
		return torf;
	}
	
	//This method returns a boolean 
	//whether or not each successive data point is lower than the previous one. 
	
	
	public String getTrend() {
		String trend = "no trend";
		if(trendsUp() == true && trendsDown() == false) {
			trend = "up";
		} else {
			if(trendsDown() == true && trendsUp() == false) {
				trend = "down";
			} 
		}
		return trend;
	}
	//This method returns up, down, or no trend 
	//depending on trendsDown() and trendsUp() method.
	
	public String toString() {
		String intro = "This is the \"" + series + "\" for " + name;
		String lineYears = "";
		String lineData = "";
		
		
		for(int i = 0; i < (this.years).size(); i++) {
			lineYears += years.get(i) + "\t\t";
			lineData += values.get(i) + "\t\t";
		}
		
		String stringMin = "Minimum: " + min();
		String stringMax = "Maximum: " + max();
		String trend = "Trending: " + getTrend();
		String title = getAcronym() + " for " + years.get(0) + "-" + years.get(years.size()-1);
		//String title = getAcronym() + " for " + years.get(0) + "-" + years.get(years.size()-1);
 		return title + "\n" + lineYears + "\n" + lineData + "\n" + intro + "\n" + stringMin + "\n" + stringMax + "\n" + trend + "\n";
	}
	//This method prints everything out for each country object in a spreadsheet format.
}
