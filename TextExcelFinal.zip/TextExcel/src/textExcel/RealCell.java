package textExcel;

/*
 * Description: RealCell object, this will deal with numeric values in cells and caluclations. 
 * It can be a value cell, percent cell, or formula cell. 
 * @author: natalieluong
 * @version: 02.22.23
 */

public class RealCell implements Cell{
	private String input; 
	
	//Constructor, takes in a numeric value and sets it to the private field input
	public RealCell(String value) {
		input = value;
	}

	//Converts the input to an actual double value so it can be usable in caluclations.
	public double getDoubleValue() {
		return Double.parseDouble(input);
		
	}
	
	//Returns the entire exact value as what was inputted.
	public String fullCellText() {
		return input;
	}
	
	//If the value is less than ten, it will return the value plus extra spaces that 
	//can make it 10 characters only. Otherwise, it will return the first ten characters
	//of the value.
	public String abbreviatedCellText() {
		String value = String.valueOf(getDoubleValue()); //Necessary to change everything to doubles (like if we had ints)
		String shortened = "";
		if(value.length() > 10) {
			shortened = value.substring(0,10);
		}else {
			shortened += value;
			int howManySpaces = 10 - shortened.length();
			for(int i = 0; i < howManySpaces; i++) {
				shortened += " ";
			}
		}
		return shortened;
	}
	
	
}
