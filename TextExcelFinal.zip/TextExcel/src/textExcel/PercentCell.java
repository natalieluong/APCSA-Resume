package textExcel;
/*
 * Description: Percent cell object, subclass of ValueCell so that it can use the 
 * getDoubleValue() from ValueCell as a form of polymorphism
 * @author: natalieluong
 * @version: 02.22.23
 */

public class PercentCell extends ValueCell{
	private String value;
	
	//Constructor, sets private field to an inputted percent
	//Calls superclass' constructor to use the getDoubleValue() later
	public PercentCell(String input) {
		super(input);
		value = input;
	}
	
	
	//This returns a shortened version of the original percent so that it can 
	//fit in the spreadsheet. Includes the first to 9th character without rounding and 
	//an additional percent character.
	public String abbreviatedCellText() {
		String returnValue = "";
		String printValue = "";
		
		if(value.contains(".")) {
			int whereDot = value.indexOf(".");
			printValue = value.substring(0, whereDot);
		}else {
			printValue = value;
		}
		
		
		if(printValue.length() > 9) {
			returnValue = printValue.substring(0,9) + "%"; //% is the 10th element
		}else {
			returnValue = printValue + "%";
			int howManySpaces = 9 - printValue.length();
			for(int i = 0; i < howManySpaces; i++) {
				returnValue += " ";
			}
		}
		return returnValue;
	}
	
	//Returns the decimal value of a percent by dividing it by 100. 
	public String fullCellText() {
		double divide = (getDoubleValue() / 100);
		return String.valueOf(divide);
	}
}
