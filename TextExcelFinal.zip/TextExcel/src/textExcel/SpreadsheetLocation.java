/*
 * Description: SpreadsheetLocation class, this will deal with cell references such as
 * C20 or A5, and will have the getRow() and getCol() methods to return the 
 * column (letter) and row (number).
 * @author: natalieluong
 * @version: 02.22.23
 */
package textExcel;

public class SpreadsheetLocation implements Location
{
	private String cell;
	
	//Constructor, takes in a cell reference such as A2 or B18
	public SpreadsheetLocation(String cellName)
    {
		cell = cellName;
    }
	
    @Override
    //Uses the private field cell and takes everything after the first character
    //because it will be numbers aka a row.
    public int getRow()
    {
        return Integer.parseInt(cell.substring(1))-1;
    }

    @Override
    //Uses the private field cell and takes the first character because it will be a letter
    //aka a column.
    public int getCol()
    {
        return cell.toUpperCase().charAt(0) - 'A';
    }
    
    
    

}
