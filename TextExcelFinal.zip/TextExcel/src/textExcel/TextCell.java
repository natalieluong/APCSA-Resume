package textExcel;
/*
 * Description: TextCell object, this will deal with string inputs from a user's command. 
 * This will display either a shortened version of the whole string without quotations or 
 * returns the entire string with quotations when called on. 
 * @author: natalieluong
 * @version: 02.22.23
 */

public class TextCell implements Cell{
	private String cell;
	
	
	//When a cell is being inspected, this method will return the exact inputted string.
	public String fullCellText(){
		return cell;
	}
	
	//When a cell is assigned or displayed on the spreadsheet, it will show the
	//first ten characters of the string.
	public String abbreviatedCellText() {
		if(cell.length() > 11) {
			return fullCellText().substring(1,11);
		}else {
			String noQuotes = fullCellText().substring(1,fullCellText().length()-1);
			int howManySpaces = 10 - noQuotes.length();
			for(int i = 0; i < howManySpaces; i++) {
				noQuotes += " ";
			}
			return noQuotes;
			
		}
		
	}
	
	//Constructor, sets the inputted string to the private field cell.
	public TextCell(String input) {
		cell = input;
	}

}
