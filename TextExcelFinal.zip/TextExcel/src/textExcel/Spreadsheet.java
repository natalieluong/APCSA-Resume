package textExcel;

/*
 * Description: Spreadsheet class that determines what type of input a user gives, 
 * such as an assignment, inspection, or clearing command. It will then call other classes
 * to return a correct output. 
 * This will create and print out a 2D array of cells with 20 columns and 12 rows.
 * 
 * @author: natalieluong
 * @version: 02.22.23
 */

public class Spreadsheet implements Grid
{
	private Cell[][] cells;
	
	//Constructor, sets private field cells to have 20 columns and 12 rows to store values
	public Spreadsheet()
	{
		cells = new Cell[getRows()][getCols()];
		for(int i = 0; i < getRows(); i++) {
			for(int j = 0; j < getCols(); j++) {
				cells[i][j] = new EmptyCell();
			}
		}
	}
	
	
	@Override
	//Called by the main method in TextExcel, it determines what type of input the user 
	//types which is given by the parameter command.
	//Returns a gridText (spreadsheet) of the updated values.
	public String processCommand(String command)
	{
		
		
		String result = "";
		
		
		//INSPECT:
		  //This should only be cell references such as A1 or B20. 
	      //The returned result will be the exact value of what's stored in the cell.
		if(command.length() == 2 || command.length() == 3) {
				SpreadsheetLocation loc = new SpreadsheetLocation(command);
				result = getCell(loc).fullCellText();
		}
		
		//ASSIGNMENT:
		  //The command will have a variation that deals with setting a cell to a command
		  //This can be a string, single value, a formula, or a percentage.
		  //To determine if it is an assignment, it should contain "="
		  //From there, if it contains quotations, it will be a string.
		  //if it has "%", it will be a percentage.
		  //If it has parentheses, it will be a formula.
		  //And if none of those cases apply, it should be a value or number.
		
		if(command.contains("=")) {
				
			String[] separate = command.split(" ", 3);
			SpreadsheetLocation loc = new SpreadsheetLocation(separate[0]);
			//Setting up the location and array to find what we're assigning
				
			if(command.contains("\"")) {
				
				TextCell text = new TextCell(separate[2]);
				cells[loc.getRow()][loc.getCol()] = text;
				result = getGridText();
					
			}else{
				if(command.contains("%")) {
					PercentCell percent = new PercentCell(separate[2].substring(0,separate[2].length()-1));
					cells[loc.getRow()][loc.getCol()] = percent;
					result = getGridText();
				} else if(command.contains("(")) {
					String noParentheses = separate[2].substring(2,separate[2].length()-2);
					FormulaCell formula = new FormulaCell(noParentheses, this);
					//Get everything besides the outside parentheses and spaces
					
					cells[loc.getRow()][loc.getCol()] = formula;
					result = getGridText();
				} else {
					ValueCell value = new ValueCell(separate[2]);
					cells[loc.getRow()][loc.getCol()] = value;
					result = getGridText();
				}
			}
				
	}

		//CLEAR: 
		//This command clears the entire spreadsheet. 
		//Every cell will be set to an emptyCell.
		if(command.equalsIgnoreCase("clear")) {
			for(int i = 0; i < cells.length; i++) {
				for(int j = 0; j < cells[i].length; j++) {
					cells[i][j] = new EmptyCell();
				}
			}
			result = getGridText();
		}
		//CLEAR CELL:
		//This command will clear a cell specified by the user. 
		//It will set the cell to an emptyCell. 
		if(command.length() > 5) {
			if(command.substring(0,5).equalsIgnoreCase("clear") && (command.length() == 8 || command.length() == 9)){
				String[] getLocation = command.split(" ");
				SpreadsheetLocation loc = new SpreadsheetLocation(getLocation[1]);
				cells[loc.getRow()][loc.getCol()] = new EmptyCell(); 
				//How to set that cell to an empty one?
				result = getGridText();
			}
		}
		
		return result;
	}
	
	@Override
	//Getter to return the number of rows (numbered rows) of the spreadsheet
	public int getRows()
	{
		return 20;
	}

	@Override
	//Getter to return the number of columns (lettered columns) of the spreadsheet
	public int getCols()
	{
		return 12;
	}

	@Override
	//Getter to return the cell at a specified location.
	public Cell getCell(Location loc)
	{
		//Checkpoint 1: return null;
		return cells[loc.getRow()][loc.getCol()];
	}
	
	//A special overriden getCell method where instead of a location, it takes 
	//in a specified row and column. 
	public Cell getCell(int row, int col) {
		return cells[row][col];
	}

	@Override
	//This will create the visual spreadsheet instead of the code spreadsheet (2D array).
	//This includes creating the lines, numbering the columns and rows, and 
	//setting each appropriate cell to the values in the private field. 
	public String getGridText()
	{
		//Checkpoint 1: return null;
		//Checkpoint 2: Create the grid!
		
		//1. This prints the first row with all the column labels. 
		String grid = "";
		
		grid += ("   |");
	    for(int j = 0; j < getCols(); j++) {
	    	char letter = (char) ('A' + j);
	    		grid += (letter + "         |");
	    }
	    grid += "\n";
	    
	  
	    //2. Nested loop to create all 20 rows.
	    for(int i = 1; i <= getRows(); i++) {
	    	//Add the first column where all the row #'s are
	    	if(i >= 10) {
	    		grid += (i + " |");
	    	}else {
	    		grid += (i + "  |");
	    	}
	    	//Then, in each of those rows, get the cell 
	    	for(int j = 1; j <= getCols(); j++) {
	    		grid += (cells[i-1][j-1].abbreviatedCellText()+ "|");
	    	}
	    	grid += "\n";
	    	
	    }
	    return grid;
	}

}
