package textExcel;

/*
 * Description: ValueCell object, this is a variation of a real cell, which will only 
 * deal with integers and doubles. Basically functional without changing any methods
 * in the super class.
 * @author: natalieluong
 * @version: 02.22.23
 */

public class ValueCell extends RealCell{
	private String value; 
	
	//Constructor, takes in and stores a int or double value in the form of a string
	public ValueCell(String input) {
		super(input);
		value = input;
	}
	
	//Converts the string value to a double by calling the super method.
	public double getDoubleValue() {
		return super.getDoubleValue();
	}
	
	//Returns the entire inputted value by calling the super method.
	public String fullCellText() {
		return super.fullCellText();
	}
	
	//Returns a shortened version of the exact value by calling the super method. 
	public String abbreviatedCellText() {
		return super.abbreviatedCellText();
	}
}
