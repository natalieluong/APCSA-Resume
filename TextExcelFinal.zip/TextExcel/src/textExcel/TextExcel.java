/*
 * Description: Client class, takes in user inputs by calling process command
 *  and prints out the spreadsheet (and updated ones after each time the user inputs
 * @author: natalieluong
 * @version: 02.22.23
 */
package textExcel;

import java.io.FileNotFoundException;  
import java.util.Scanner;

// Update this file with your own code.

public class TextExcel
{

	//Main method responsible for dealing with user's commands 
	//and implementing the code correctly
	//While the user does not want to stop (quit), it will keep asking for a command and
	//calling processCommand, which will print out the spreadsheet with the updated commands.
	public static void main(String[] args)
	{
		Spreadsheet spread = new Spreadsheet();
	    Scanner input = new Scanner(System.in);
	    System.out.println("Insert a command: ");
	    String line = input.nextLine();
	    while(!(line.equalsIgnoreCase("quit"))) {
	    	System.out.println(spread.processCommand(line));
	    	System.out.println("Insert a command: ");
	    	line = input.nextLine();
	    	
	    }
	    
	    input.close();
	}
}
