package textExcel;
/*
 * Description: Formula cell object, evaluates an expression given by the user which can
 * be finding the sum or average of a range of cells or a string of one value or an expression
 * @author: natalieluong
 * @version: 02.22.23
 */


public class FormulaCell extends RealCell{
	private String formula;
	private Spreadsheet sheet;
	
	//Another constructor so that we can evaluate formulas with cell variables
	//such as A1, B20, c3
	public FormulaCell(String input, Spreadsheet spread) {
		super(input);
		formula = input;
		sheet = spread;
	}
	
	//Constructor for regular values, such as 4, 5.0, 23.65
	public FormulaCell(String input) {
		super(input);
		formula = input;
	}
	
	//Helper method to make getDoubleValue() more readable
	//This evaluates the sum of a range of values such as A1-A3, B2-D4
	public double sumOf(String locToLoc) { 
		
		double sum = 0;
		String[] locs = locToLoc.split("-");
		
		SpreadsheetLocation firstLoc = new SpreadsheetLocation(locs[0]);
		SpreadsheetLocation secLoc = new SpreadsheetLocation(locs[1]);
		
		for(int i = firstLoc.getRow(); i <= secLoc.getRow(); i++) {
			for(int j = firstLoc.getCol(); j <= secLoc.getCol(); j++) {
				
				RealCell real = (RealCell) sheet.getCell(i, j);
				sum += real.getDoubleValue();
			}
		}
		return sum;
	}
	
	public double getDoubleValue( ) { 
		
		//1. Split the formula into different components
		//such that the values/variables will be separate from operations
		String[] separate = formula.split(" ");
		
		//2. formulaResult will store the evaluation of a formula.
		double formulaResult = 0; 
		
		
		//3. Formula will either evaluate a SUM, AVG, or regular values.
		//Determine the first case if the formula will contain SUM.
		//Uses sumOf helper method for readability.
		
		if(separate[0].equalsIgnoreCase("sum")){
			formulaResult = sumOf(separate[1]);
			
		
		//4. Determine the second case if the formula will contain AVG. 
		//Lines 70-75 evaluates how many cells will be in the range by doing 
		//length x width using the cell column letter and the cell row number.
		//Calls sumOf to evaluate the sum and divide by the # of cells.

		}else if(separate[0].equalsIgnoreCase("avg")){ 
			String[] sepLoc = separate[1].split("-");
			
			
			String upperCharOne = sepLoc[0].substring(0,1).toUpperCase();
			int length1 =  upperCharOne.charAt(0) - 65;
			String upperCharTwo = sepLoc[1].substring(0,1).toUpperCase();
			int length2 = upperCharTwo.charAt(0) - 65;
			int actualLength = length2 - length1 + 1;
			int width = Integer.parseInt(sepLoc[1].substring(1)) - Integer.parseInt(sepLoc[0].substring(1)) + 1;
			
			formulaResult = sumOf(separate[1]) / (actualLength * width);
 
		}else {
		//5. This is the last case where we don't have SUM or AVG. 
		//The first try catch will set formulaResult to the first value of the formula
		//and it will set numeric true if the value is a number, otherwise false if it
		//is a cell reference. 
		//Using a for-loop, it will alternate between looking at what operation to what 
		//value it is. This way, formulaResult will keep updating accordingly.
			
			boolean numeric = true;
			double num = 0;
			
			try{
				formulaResult = (Double.parseDouble(separate[0]));
				
			}catch(NumberFormatException e) {
				SpreadsheetLocation loc = new SpreadsheetLocation(separate[0]);
				RealCell real = (RealCell) sheet.getCell(loc);
				
				num = real.getDoubleValue();
				formulaResult = num;
			}
			
			for(int i = 1; i < separate.length-1; i+=2) {
					try{
						num = (Double.parseDouble(separate[i+1]));
						numeric = true;
						
					}catch(NumberFormatException e) {
						numeric = false; 
					}
					
					if(numeric == false){
						SpreadsheetLocation loc = new SpreadsheetLocation(separate[i+1]);
						RealCell real = (RealCell) sheet.getCell(loc);
						
						num = real.getDoubleValue();
					}
					
					
					
					if((separate[i]).equals("+")) {
						formulaResult += num;
					}
					if((separate[i]).equals("-")) {
						formulaResult -= num;
					}
					if((separate[i]).equals("*")) {
						formulaResult *= num;
					}
					if((separate[i]).equals("/")) {
						formulaResult /= num;
					}
				}
			
			
		}
		return formulaResult;
		
	}
	
	//When printed on the spreadsheet, the evaluated formula will be printed and shortened 
	//if longer than 10 characters. 
	public String abbreviatedCellText() {
		
		String shortened = String.valueOf(getDoubleValue());
		if(shortened.length() > 10) {
			shortened = shortened.substring(0,10);
		}else {
			int howManySpaces = 10 - shortened.length();
			for(int i = 0; i < howManySpaces; i++) {
				shortened += " ";
			}
		}
		return shortened;
	}
	
	//When inspected, fullCellText will return the formula inputted by the user. 
	public String fullCellText() {
		return "( " + super.fullCellText() + " )";
	}
}
