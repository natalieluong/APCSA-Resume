/*
 * Methods required to analyze a quadratic formula.
 * @author natalieluong
 * @version 09.23.22
 */
public class Quadratic {
	
	/*------------------------------------------------------------------
	                            OLD CODE
	------------------------------------------------------------------*/

	//------------------------------------------------------------------
	//disc
	public static double discriminant(double a, double b, double c) {
		double discriminant; 
		discriminant = (b*b) - (4*a*c);
		return discriminant;
		}
	
	//------------------------------------------------------------------
	//absValue
	public static double absValue(double a) {
		double absolute = a;//Finds the absolute value given a double.
		if(absolute<0) {
			absolute = 0 - absolute;
		}
		return absolute;
	}
	
	//------------------------------------------------------------------
	//round2
	public static double round2(double a) { //This is the correct round method.
		double threeDigits = absValue(a) * 1000; //It rounds 'a' to the hundredth.
		int lastDigit = (int) threeDigits % 10;
		if(lastDigit >= 5) {
			threeDigits += 10;
		}
		double onlyTwo = threeDigits/10;
		int removeFourth = (int) onlyTwo;
		double answer = (double) removeFourth / 100;
		if(a<0) {
			answer = 0-answer;
		}
		return answer;
	}
	
	//------------------------------------------------------------------
	//square root
	public static double sqrt(double a) { 
		double guess = a/2;
		if(a<0) {
			throw new IllegalArgumentException("Error: Cannot root a negative number");
		}
		while((absValue(guess*guess)-a)>.005) {
			guess = ((a/guess)+guess) / 2;
		}
		return round2(guess);
		}
	
	//------------------------------------------------------------------
	//quadForm
	public static String quadForm(double a, double b, double c) {
		if(discriminant(a,b,c) < 0) {
			return "\nx-intercepts(s): None";
		}
		double quad1 = ( (0-b) + sqrt(discriminant(a,b,c))) / (2*a);
		double quad2 = ( (0-b) - sqrt(discriminant(a,b,c))) / (2*a);
		if(quad1 == quad2) {
			return "\nx-intercept(s): " + quad1;
		}
		return "\nx-intercept(s): " + round2(quad1) + " and " + round2(quad2);
	}
	
	/*------------------------------------------------------------------
	                              NEW CODE
	------------------------------------------------------------------*/
	
	public static String quadDescriber(double a,double b,double c) {
		//Description -- equation in standard form
		String equation = "y= " + a + "x^2 + " + b + "x + " + c;
		
		//Opens -- negative/ positive sign
		String opens = "";
		if(a<0) {
			opens = "Down";
		}else {
			opens = "Up";
		}
		
		//------------------------------------------------------------------
		//Axis of Symmetry -- vertical line that divides the parabola equally in half
		double axis = (0-b)/(2*a);
		
		//------------------------------------------------------------------
		//Vertex -- for the equation y=a(x-h)^2 + k - (h,k)
		double h = (0 - b) / (2 * a);
		double k = (0 - discriminant(a,b,c)) / (4 * a);
		
		//------------------------------------------------------------------
		//y-int -- when x = 0, the equation will be y = c
		double y = c;
		
		
		return "Description of the graph of: " + equation + "\n\nOpens: " + opens + "\nAxis of Symmetry: " + axis + "\nVertex: (" + h + ", " + k + ")\ny-intercept: " + c;
		
		//quadForm()
		//discriminant() 
		//sqrt()
		//absValue()
		//round2()
		//max
		//min
	}

}
