/**
 * 
 * Client code for Calculate Part 5
 * @author natalieluong
 * @version 09.23.22
 */
import java.util.Scanner;
public class QuadraticClient {

	public static void main(String[] args) {
		//greeting
		//loop(while)
			//get input from user
			//call QuadraticDescriber() to analyze the function and return Strings
			//print the results
			//ask -- go again?
			//get answer
		String quits = "";
		Scanner quit = new Scanner(System.in);
		System.out.println("Welcome to the Quadratic Describer!");
		while(quits.equals("quit")==false) {
			Scanner userInput = new Scanner(System.in);
			System.out.println("Provide values for coefficient a, b, and c\na: ");
			double answerA = userInput.nextDouble();
			System.out.println("b: ");
			double answerB = userInput.nextDouble();
			System.out.println("c: ");
			double answerC = userInput.nextDouble();
			System.out.print(Quadratic.quadDescriber(answerA,answerB,answerC));
			System.out.print(Quadratic.quadForm(answerA,answerB,answerC));
			System.out.println("\nDo you still want to keep going? (Type \"quit\" to end)");
			quits = quit.next();
		}
		System.out.println("Thank you for using QuadraticDescriber.");
		}
		
	}

