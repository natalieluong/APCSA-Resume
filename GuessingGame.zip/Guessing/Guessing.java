/*
 * Guessing game - Prompts user for a range and their guessing number and compares it to a randomly generated number in that range
 * @author natalieluong
 * @version 09.28.22
 */
import java.util.*;

public class Guessing 
{

	public static int getRandomNumber(int low, int high)//don't touch
	{
		// Math.random() returns a decimal in the range [0, 1)
		// Pick a low and high value and test this out.  Can the 
		// computer choose the low and high bounds as its number?
		int rand = (int) (Math.random() * (high - low + 1)) + low;
		return rand;
	}
	
	public static String compareToSecret(int guessedNum, int secretNum)
	{
		String guessIs = "";
		if (guessedNum < secretNum)
			guessIs = "low";
		else
			guessIs = "high";
		return guessIs;
	}
	
	public static boolean inRange(int low, int high, int num)
	{
		if (low <= num && num <= high)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public static void main(String[] args) 
	{
		//Ask for user name:
		Scanner nameInput = new Scanner(System.in);
		System.out.println("Please enter your name: ");
		String name = nameInput.next();

		//playAgain will set to "Y" in order to execute the while loop at least once. 
		String playAgain = "Y";
		while(playAgain.equals("Y")){ 
			
			
			//Greets user by their name.
			Scanner greeting = new Scanner(System.in);
			System.out.println("Welcome to the Guessing Game, " + name + "!");

			
			//Get lowest value in range:
			Scanner lowInput = new Scanner(System.in);
			System.out.println("Please enter the smallest value for your range: ");
			int lowest = lowInput.nextInt();

			
			//Get highest value in range:
			Scanner highInput = new Scanner(System.in);
			System.out.println("Please enter the highest value for your range: ");
			int highest = highInput.nextInt();
			
			
			//Check to see if highest is really the highest value.
			//In other words, highest must be higher than lowest in order to continue the loops.
			//Else, an error would stop the code entirely.
			if(highest<lowest) { //
				throw new IllegalArgumentException("Error: " + highest + " is lower than the lowest " + lowest);
			}
			int secret = getRandomNumber(lowest, highest);
				
			Scanner ask = new Scanner(System.in);
			System.out.println("Give me a number : ");
			int guess = ask.nextInt();
			
//----------------------------------------------------------------------------------------------------------------------		
				
			//BREAK TO SEPARATE THE TWO WHILE LOOPS:
			//Initializes isWrong to be true in order to keep the loop going.
			//This checks to see if our guess is wrong...
			//If isWrong is false, then our guess is not wrong.
			//If isWrong is true, then our guess is wrong.
			boolean isWrong = true;
			while(isWrong==true) {
				
				if(guess<lowest || guess>highest) { //Error if guess is out of range
					throw new IllegalArgumentException("Error: " + guess + " is out of bound between " + lowest + " and " + highest);
				}
				if (secret == guess)
				{ //If we guessed correctly, it'll give feedback and exit the loop.
					System.out.println("You guessed right!");
					System.out.println("My number was " + secret + "!");
					isWrong = false;
				}
				else 
				{ //If we guessed incorrectly, we ask the user to guess again and the while loop continues until it's correct.
					String lowHigh = compareToSecret(guess, secret);
					System.out.println("Nope. " + guess + " is too " + lowHigh);
					isWrong = true;
					Scanner askAgain = new Scanner(System.in);
					System.out.println("Guess again!");
					guess = ask.nextInt();
				}
				
			}
			//Exited the while loop...
			//Asking to play again: 
			Scanner repeat = new Scanner(System.in);
			System.out.println("Would you like to play again? [Y] [N]");
			playAgain = repeat.next();
			
			//If user says "Y", the while(playAgain.equals("Y")) will be true and repeat-
			//-until the user says anything besides "Y".
			
			if(playAgain.equals("Y")) { 
				playAgain = "Y";
				
			//Regardless if the user types "N" correctly or not, it'll still end the code and bid farewell.
			}else {
				System.out.println("Thank you for playing!"); 
			}
		}
	}
}

	
		
