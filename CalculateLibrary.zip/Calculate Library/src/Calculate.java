/**
 * 
 * This library will contain various methods to solve different equations.
 * Each parameter will require DoMath.java to insert a value in order to use these
 * methods.
 * This library includes parts 1-4 methods.
 * Side note: I made two versions of round2 and sqrt because I wanted to simplify the 
 * first prototype. They all work the same, but the comments will label them. :)
 * Another side note: The Quadratic Formula may compute an higher rounded number because 
 * it's passed through the sqrt function twice. 
 *    
 * @author natalieluong
 * @version 8.26.22-09.14.22
 *
 */
public class Calculate {
	//returns square of input
	public static int square(int number) { //Finds the number to the power of 2.
		int answer;
		answer = number*number;
		return answer;
	}
	public static int cube(int number) { //Finds the number to the power of 3.
		int answer2;
		answer2 = number*number*number;
		return answer2;
	}
	public static double average(double number, double number2) { //Finds the average of 2 numbers.
		double average;
		average = (number + number2) / 2;
		return average;
	}
	public static double average(double num, double num2, double num3) {//Finds the average of 3 numbers.
		double average;
		average = (num+num2+num3) / 3;
		return average;
	}
	public static double toRadians(double degree) {//Finds the radian given a degree value.
		double radians;
		radians = degree * (3.14159/180);
		return radians;
	}
	public static double toDegrees(double radian) {//Finds the degree given a radian value.
		double degrees;
		degrees = radian * (180/3.14159);
		return degrees;
	}
	public static double discriminant(double a, double b, double c) {
		double discriminant; //Finds the inside of a square root in a quadratic formula.
		discriminant = (b*b) - (4*a*c);//Determines # of solutions of a quadratic formula.
		return discriminant;//Real, repeated, or no roots?
	}
	public static String toImproperFrac(int a, int b, int c) {
		int fraction = ((a*c)+b);
		String improper = fraction + "/" + c;
		return improper;//Turns 3 #s (in the order of a simplified fraction into an improper fraction.
	}
	public static String toMixedNum(int a, int b) {//Simplifies an improper fraction. 
		int num = a/b;
		int extra = a%b;
		String mixed = num + "_" + extra + "/" + b;
		return mixed;
	}
	public static String foil(int a, int b, int c, int d, String e) {
		int first = a*c;//Turns a factored form into a standard form.
		int second = (a*d) + (b*c);
		int third = b*d;
		String equation = first + e + "^2 + " + second + e + " + " + third;
		return equation;
	}
	public static boolean isDivisibleBy(int a, int b) {
		if(b==0) {//Figures out if a is divisible by b. Returns true or false. 
			throw new IllegalArgumentException("Error: Denominator cannot be 0");
		}
		return a % b == 0;
	}
	public static double absValue(double a) {
		double absolute = a;//Finds the absolute value given a double.
		if(absolute<0) {
			absolute = 0 - absolute;
		}
		return absolute;
	}
	public static double max(double a, double b) {
		double max = a;//Finds which one of a or b is bigger. 
		if(b>a) { //Finds the maximum between two doubles. 
			max = b;
		}
		return max;
	}
	public static double max(double a, double b, double c) {
		double max = a;//Finds which one of a,b, or c is bigger.
		if(b>max) {//Finds the maximum between three doubles. 
			max = b;
		}
		if(c>max) {
			max = c;
		}
		return max;
	}
	public static int min(int a, int b) {
		int min = a;//Finds the minimum between two integers.
		if(b<min) {
			min = b;
		}
		return min;
	}
	public static double min(double a, double b) {
		double min = a;//Finds the minimum between two integers.
		if(b<min) {
			min = b;
		}
		return min;
	}
	public static double round3(double a) { //Don't look at this.
		double fourDigits = a * 1000;//It was my first prototype :)
		int round = (int) fourDigits;
		double threeDigits = a * 100;
		int roundtwo = (int)threeDigits;
		int endZero = roundtwo * 10;
		int oneDigit = (int)round - endZero;
		if(oneDigit >= 5) {
			endZero += 10;
		}else if(oneDigit <= 5) {
			endZero += 0;
		}
		double answer = (double)endZero / 1000;
		return answer;
		
	}
	public static double round2(double a) { //This is the correct round method.
		double threeDigits = absValue(a) * 1000; //It rounds 'a' to the hundredth.
		int lastDigit = (int) threeDigits % 10;
		if(lastDigit >= 5) {
			threeDigits += 10;
		}
		double onlyTwo = threeDigits/10;
		int removeFourth = (int) onlyTwo;
		double answer = (double) removeFourth / 100;
		if(a<0) {
			answer = 0-answer;
		}
		return answer;
	}
	public static double exponent(double a, int b) {
		double initial = a;//Finds the result of a to the b power.
		if(b < 0 || (a == 0 && b == 0)) {
			throw new IllegalArgumentException("Error: "+b+" is less than 0.");
		}
		for(int i = 1;i<b;i++) {
			initial *= a;
		}
		if (b == 0) {
			initial = 1;
		}
		return initial;
	}
	public static int factorial(int a) {
		int factorial = a;//Finds the factorial of a.
		if(a < 0) { //Finds a!
			throw new IllegalArgumentException("Error: " + factorial + " is less than 0.");
		}
		if(a>=20) {
			System.out.println("The output will be inaccurate because number is too big: ");
		}
		for(int i = 1; i<a; i++) {
			factorial *= i;
		}
		return factorial;
	}
	public static boolean isPrime(int a) { //Determines whether a is prime or not.
		boolean tf = true; // returning true = it is a prime
		for(int i = 2; i<a; i++) {
			if(isDivisibleBy(a,i)==true) {
				tf = false;
			}
		}
		if(a==1 || a ==0) {
			System.out.print("Not a prime nor composite number - ");
		}
		return tf;
	}
	public static int gcf(int a, int b) { //Finds the greatest common factor between a and b.
		int gcd = a;
		for(int i = 1; a >= i && b >= i; i++) {
			if(isDivisibleBy(a,i) == true && isDivisibleBy(b,i)==true) {
				gcd = i;
			}
		}
		return gcd;
	}
	public static double sqrt(double a) { //This is the correct sqrt.
		double guess = a/2;//Finds the root of a double. 
		if(a<0) {
			throw new IllegalArgumentException("Error: Cannot root a negative number");
		}
		while((absValue((guess*guess)-a))>.005) {
			guess = ((a/guess)+guess) / 2;
		}
		return round2(guess);
		}

	public static double sqrt2(double a) { //longer version
		double diff = 1;//Don't look at this!
		double guess = a;//First prototype!
		double guesstwo = 1;
		while(diff > 0.005) { //b * b) - a<=0.005
			guesstwo = guess - (((guess * guess)-a) / (2*guess)); //5
			diff = guesstwo - guess;
			if(diff<0) {
				diff *= -1;
			}
			guess = guesstwo;
		}
		return round2(guesstwo);
		
		}
	public static String quadForm(int a, int b, int c) {
		if(discriminant(a,b,c) < 0) {//Finds the roots given a,b,c from standard form.
			return "no real roots";//Plugs them into the quadratic formula.
		}
		double quad1 = (double) (((-b) + sqrt(discriminant(a,b,c))) / (2*a));
		double quad2 = (double) (((-b) - sqrt(discriminant(a,b,c))) / (2*a));
		if(quad1 == quad2) {
			return Double.toString(round2(quad1));
		}
		return min(round2(quad2),round2(quad1)) + " and " + max(round2(quad2),round2(quad1));
	}
	}

